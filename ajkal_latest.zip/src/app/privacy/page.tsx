import Privacy from "@/components/Privacy/Privacy";
import React from "react";

const page = () => {
  return (
    <div>
      <Privacy />
    </div>
  );
};

export default page;
