import Archive from '@/components/Archive/Archive';
import React from 'react';

const page = () => {
    return (
        <div>
            <Archive />
        </div>
    );
};

export default page;