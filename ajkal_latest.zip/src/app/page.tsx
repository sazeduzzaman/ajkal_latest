import HomePage from "@/components/HomePage/HomePage";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "আজকাল || Ajkal - সর্বশেষ বাংলা সংবাদ",
  description:
    "আজকাল এ পড়ুন সর্বশেষ বাংলা খবর, রাজনীতি, খেলাধুলা, বিনোদন ও আরও অনেক কিছু। বাংলাদেশ ও বিশ্বের আপডেট সংবাদ সবার আগে।",
  keywords: [
    "আজকাল",
    "Ajkal",
    "বাংলা খবর",
    "নিউজ",
    "বাংলাদেশ",
    "খেলা",
    "রাজনীতি",
    "বিনোদন",
  ],
  metadataBase: new URL("https://ajkal.us"), // update to your domain
  openGraph: {
    title: "আজকাল || Ajkal - বাংলা খবর",
    description:
      "বাংলাদেশ ও বিশ্বের সর্বশেষ সংবাদ পড়ুন আজকাল এ। সব সময় আপডেট থাকুন।",
    url: "https://ajkal.us",
    siteName: "আজকাল || Ajkal",
    type: "website",
    images: [
      {
        url: "/images/placeholderImage.webp",
        alt: "আজকাল || Ajkal - বাংলা খবর",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "আজকাল || Ajkal - বাংলা সংবাদ",
    description:
      "আজকাল এ সর্বশেষ সংবাদ, রাজনীতি, খেলাধুলা ও বিনোদনের খবর পড়ুন।",
    images: ["/images/placeholderImage.webp"],
  },
};

export default function Home() {
  return (
    <div className="max-w-7xl mx-auto">
      <HomePage />
    </div>
  );
}
