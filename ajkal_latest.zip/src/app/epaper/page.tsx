import Epaper from "@/components/Epaper/Epaper";
import React from "react";

const page = () => {
  return <Epaper />;
};

export default page;
