import Contact from '@/components/Contact/Contact';
import React from 'react';

const page = () => {
    return (
        <div>
            <Contact />
        </div>
    );
};

export default page;