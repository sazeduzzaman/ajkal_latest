import Terms from '@/components/Terms/Terms';
import React from 'react';

const page = () => {
    return (
        <div>
            <Terms />
        </div>
    );
};

export default page;