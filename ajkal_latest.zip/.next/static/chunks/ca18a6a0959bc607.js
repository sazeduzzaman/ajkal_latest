__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/2482537d7411b239.js",
  "static/chunks/turbopack-2cfca77d566c55b8.js"
])
