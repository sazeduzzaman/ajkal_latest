__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/2482537d7411b239.js",
  "static/chunks/turbopack-2d8f90a9de9927a2.js"
])
