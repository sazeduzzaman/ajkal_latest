globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/2482537d7411b239.js",
      "static/chunks/turbopack-2d8f90a9de9927a2.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/2482537d7411b239.js",
      "static/chunks/turbopack-2cfca77d566c55b8.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/be0181a504c3dd6f.js",
    "static/chunks/569f8ca39997ccda.js",
    "static/chunks/150316a471952cee.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/turbopack-16614bf37b731e73.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];